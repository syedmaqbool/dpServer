import express from 'express';
import controller from '../controllers/posts';
import userController from '../controllers/user';
import lotsController from '../controllers/parking_lots';
import slotController from '../controllers/slots';
import bookingController from '../controllers/bookings';
const router = express.Router();

// router.get('/posts', controller.getPosts);
// router.get('/posts/:id', controller.getPost);
// router.put('/posts/:id', controller.updatePost);
// router.delete('/posts/:id', controller.deletePost);
// router.post('/posts', controller.addPost);
router.get('/users', userController.getUsers);
router.post('/user/login', userController.getUser);
router.get('/user/slots/:id', slotController.getBookedSlots);
router.get('/area/:id', lotsController.getSlots);
router.get('/areas', lotsController.getParkingLots);
router.post('/slot/boook', bookingController.addSlot);


export = router;
