import { Request, Response, NextFunction } from 'express';
import axios, { AxiosResponse } from 'axios';
import { myDataSource } from "../config/db.config"
import { User } from "../entity/user.entity"
// interface Post {
//     userId: Number;
//     id: Number;
//     title: String;
//     body: String;
// }

interface UserData {
    id: Number;
    name: String;
    email: String;
    pwd: String;
    status: Number;
}

// getting all Users
const getUsers = async (req: Request, res: Response, next: NextFunction) => {
    const users = await myDataSource.getRepository(User).find()
    // myDataSource.c

    return res.status(200).json({
        message: users
    });

};

// // getting a single user
const getUser = async (req: Request, res: Response, next: NextFunction) => {

    let email: string = req.body.email;
    let pwd: string = req.body.pwd;

    const user = await myDataSource
        .getRepository(User)
        .createQueryBuilder("user")
        .where("email = :email AND pwd = :pwd", {email,pwd})
        .getOne()

    return res.status(200).json({
        status:user == null?300:200,
        msg:user == null?'No Record Found':'Record Found',
        data: user == null?'':user,
    });
};
//
// // updating a post
// const updatePost = async (req: Request, res: Response, next: NextFunction) => {
//     // get the post id from the req.params
//     let id: string = req.params.id;
//     // get the data from req.body
//     let title: string = req.body.title ?? null;
//     let body: string = req.body.body ?? null;
//     // update the post
//     let response: AxiosResponse = await axios.put(`https://jsonplaceholder.typicode.com/posts/${id}`, {
//         ...(title && { title }),
//         ...(body && { body })
//     });
//     // return response
//     return res.status(200).json({
//         message: response.data
//     });
// };
//
// // deleting a post
// const deletePost = async (req: Request, res: Response, next: NextFunction) => {
//     // get the post id from req.params
//     let id: string = req.params.id;
//     // delete the post
//     let response: AxiosResponse = await axios.delete(`https://jsonplaceholder.typicode.com/posts/${id}`);
//     // return response
//     return res.status(200).json({
//         message: 'post deleted successfully'
//     });
// };
//
// // adding a post
// const addPost = async (req: Request, res: Response, next: NextFunction) => {
//     // get the data from req.body
//     let title: string = req.body.title;
//     let body: string = req.body.body;
//     // add the post
//     let response: AxiosResponse = await axios.post(`https://jsonplaceholder.typicode.com/posts`, {
//         title,
//         body
//     });
//     // return response
//     return res.status(200).json({
//         message: response.data
//     });
// };

// export default { getPosts, getPost, updatePost, deletePost, addPost };
export default { getUsers, getUser};
